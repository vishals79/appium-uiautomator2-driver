package com.java.test;

import io.selendroid.client.SelendroidDriver;
import io.selendroid.common.SelendroidCapabilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

public class SelendroidTest {

	private WebDriver driver;	

	@Test
	public void selendroidTest() throws Exception {
		SelendroidCapabilities caps = new SelendroidCapabilities();
		caps.setAut("com.guru99app:1.0");
		
		driver = new SelendroidDriver(caps);
		
		System.out.print("Start executing test");
		WebElement inputField = driver.findElement(By.id("edtText"));
		System.out.println(inputField.getAttribute("enabled")+"==========");

//		Assert.assertEquals("true", inputField.getAttribute("enabled"));
		inputField.sendKeys("Hello Test");

		WebElement button = driver.findElement(By.id("btnShow"));
		button.click();

		Thread.sleep(5000);

		WebElement txtView = driver.findElement(By.id("edtText"));
		String expected = txtView.getText();
		Assert.assertEquals(expected, inputField.getText());

	}

	@AfterSuite
	public void tearDown() {
		driver.quit();
	}
}